This is forked from https://github.com/hunyadi/pyopenapi
